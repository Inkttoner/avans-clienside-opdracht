import { Module } from '@nestjs/common';
import { Neo4jModule } from 'nest-neo4j';
import { Neo4JUserController } from './neo4j.controller';
import { Neo4JUserService } from './neo4j-users.service';
import { UserModule } from '@avans-nx-workshop/backend/user';

@Module({
    imports: [Neo4jModule],
    controllers: [Neo4JUserController],
    providers: [Neo4JUserService],
    exports: [Neo4JUserService]
})
export class Neo4jBackendModule {}
