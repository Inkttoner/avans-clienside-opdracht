import { Injectable, Logger } from '@nestjs/common';
import { Neo4jService } from 'nest-neo4j/dist';

@Injectable()
export class Neo4jQuoteService {
    private readonly logger: Logger = new Logger(Neo4jQuoteService.name);

    constructor(private readonly neo4jService: Neo4jService) {}

    async findAll(): Promise<any> {
        this.logger.log('findAll users');
        const results = await this.neo4jService.read(
            `MATCH (q:Quotes) RETURN q`,
        );
        const quotes = results.records.map(
            (record: any) => record.get('q').properties 
        );
        return quotes;
    }

    async createQuote(userId: string, quoteText: string): Promise<any> {
        this.logger.log(`Creating quote for user ${userId}`);
        const result = await this.neo4jService.write(
            `
            MATCH (u:User {userID: $userId})
            CREATE (q:Quote {text: $quoteText, createdAt: datetime()})
            CREATE (u)-[:HEEFT_GEZEGD]->(q)
            RETURN q
            `,
            { userId, quoteText }
        );
        return result.records[0].get('q').properties;
    }

    async likeQuote(userId: string, quoteId: string): Promise<any> {
        this.logger.log(`User ${userId} likes quote ${quoteId}`);
        const result = await this.neo4jService.write(
            `
            MATCH (u:User {userID: $userId}), (q:Quote {id: $quoteId})
            MERGE (u)-[:LIKED]->(q)
            RETURN q
            `,
            { userId, quoteId }
        );
        return result.records[0]?.get('q').properties;
    }
    
    async dislikeQuote(userId: string, quoteId: string): Promise<any> {
        this.logger.log(`User ${userId} dislikes quote ${quoteId}`);
        const result = await this.neo4jService.write(
            `
            MATCH (u:User {userID: $userId}), (q:Quote {id: $quoteId})
            MERGE (u)-[:DISLIKED]->(q)
            RETURN q
            `,
            { userId, quoteId }
        );
        return result.records[0]?.get('q').properties;
    }
}
